<?php

namespace App\Controllers;

use App\Models\BarangMasukModel;
use App\Models\BarangModel;
use App\Controllers\BaseController;
use Dompdf\Dompdf; //Dompdf adalah suatu library PHP yang digunakan untuk menghasilkan file PDF dari HTML dan CSS
use Dompdf\Options; //konfigurasi dompdf
use PhpOffice\PhpSpreadsheet\Spreadsheet; //suatu library PHP yang digunakan untuk membuat dan mengelola spreadsheet, seperti Excel.
use PhpOffice\PhpSpreadsheet\Writer\Xlsx; //linbaryexel

class KelolaBarangMasuk extends BaseController // extends syntax inheritrn turunan class yang mempunyai anak class ada public function index dll, inheritens
{
    protected $barangMasukModel;
    protected $barangModel;
    public function __construct() //constract adalah kode yang pertama kali di baca saat di jalankan
    {
        $this->barangMasukModel = new BarangMasukModel();
        $this->barangModel = new BarangModel();
    }

    public function index() //function method index dengan enkapsulasi hak akses public
    {
        $data = [ // enskapsulasi yaitu membungkus variabel title yng membungkus histori barang 
            'title' => 'Tambah Data Barang Masuk',
            'validation' => \Config\Services::validation(),
            'barang_masuk' => $this->barangMasukModel->BarangMasuk(),
            'barang' => $this->barangMasukModel->getBarang(),
            'jenis_barang' => $this->barangMasukModel->getJenisBarang(),
        ];
        return view('kelola_barang_masuk/index', $data);
    }

   

   
    // fungsi untuk menyimpan data barang masuk sementara
    public function simpan()
    {
        $validationRules = [
            'id_barang' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kolom Barang Harus Diisi',
                ],
            ],
            'jumlah' => [
                'rules' => 'required|numeric',
                'errors' => [
                    'required' => 'Kolom Jumlah Harus Diisi',
                    'numeric' => 'Kolom Jumlah Harus Berupa Angka',
                ],
            ],
            'nominal_harga' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kolom Nominal Harga Harus Diisi',
                ],
            ],
            'total_harga' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kolom Total Harga Harus Diisi',
                ],
            ],
        ];

        if (!$this->validate($validationRules)) {
            return redirect()->to('/barang-masuk')->withInput();
        }

        $id_barang = $this->request->getVar('id_barang');
        $jumlah = $this->request->getVar('jumlah');
        $nominal_harga = $this->formatNumberWithoutSeparator($this->request->getPost('nominal_harga'));
        $total_harga = $this->formatNumberWithoutSeparator($this->request->getPost('total_harga'));
        // dd($id_barang, $jumlah, $nominal_harga, $total_harga);

        // Save the data to barang_masuk table
        $this->barangMasukModel->save([
            'id_barang' => $id_barang,
            'tanggal_masuk' => date('Y-m-d H:i:s'),
            'jumlah' => $jumlah,
            'nominal_harga' => $nominal_harga,
            'total_harga' => $total_harga,
        ]);

        // Update the stock in barang table
        $barang = $this->barangModel->find($id_barang);
        $new_stock = $barang['stok'] + $jumlah;
        $this->barangModel->update($id_barang, ['stok' => $new_stock]);

        session()->setFlashdata('pesan', 'Data Berhasil Ditambahkan');
        return redirect()->to('/barang-masuk');
    }

    private function formatNumberWithoutSeparator($number) //method atau function dengan enkapsulasi hak akses privat
    {
        return str_replace(',', '', $number);
    }


    public function hapus($id) //method funcion hapus
    {
        $this->barangMasukModel->delete($id);
        session()->setFlashdata('pesan', 'Data Berhasil Dihapus');
        return redirect()->to('/barang-masuk');
    }

    public function cetakPdf() //method function cetak pdf
    {

        $tanggalawal = $this->request->getPost('tanggalawal');
        $tanggalakhir = $this->request->getPost('tanggalakhir');


        $data = [
            'barang_masuk' => $this->barangMasukModel->filterdatatanggal($tanggalawal, $tanggalakhir),
        ]; // Data yang akan dikirim ke view 

        // Buat objek Dompdf
        $options = new Options(); // Set options baru untuk Dompdf 
        $options->set('isHtml5ParserEnabled', true); // Aktifkan parser HTML5 
        $options->set('isPhpEnabled', true); // Aktifkan PHP parser 

        $dompdf = new Dompdf($options); // Instansiasi objek Dompdf baru 

        // Render HTML ke PDF
        $html = view('kelola_barang_masuk/cetak_pdf', $data); // Get output html 
        $dompdf->loadHtml($html); // Parse html ke dalam DOMpdf 
        $dompdf->setPaper('A4', 'portrait'); // Set paper dan orientasi custom 
        $dompdf->render(); // Render html menjadi PDF

        // Output PDF ke browser
        $dompdf->stream('histori_barang_masuk.pdf', ['Attachment' => 0]);
    }

    public function cetakExcel() //method function untuk cetak exel
    {
        $barangMasuk = $this->barangMasukModel->BarangMasuk();

        $spreadsheet = new Spreadsheet(); // Membuat objek baru dari kelas Spreadsheet, yang biasanya digunakan
        // untuk membuat dan mengelola file spreadsheet, seperti Excel.
        $sheet = $spreadsheet->getActiveSheet();


        // Data
        $sheet->setCellValue('A6', 'No');
        $sheet->setCellValue('B6', 'Nama Barang');
        $sheet->setCellValue('D6', 'Tanggal');
        $sheet->setCellValue('E6', 'Jumlah');
        $sheet->setCellValue('F6', 'Nominal Harga');
        $sheet->setCellValue('G6', 'Total Harga');

        $row = 7;
        $no = 1;
        foreach ($barangMasuk as $data) {
            $sheet->setCellValue('A' . $row, $no);
            $sheet->setCellValue('B' . $row, $data['nama_barang']);
            $sheet->setCellValue('D' . $row, date('d-m-Y H:i:s', strtotime($data['tanggal_masuk'])));
            $sheet->setCellValue('E' . $row, $data['jumlah']);
            $sheet->setCellValue('F' . $row, $data['nominal_harga']);
            $sheet->setCellValue('G' . $row, $data['total_harga']);

            $row++;
            $no++;
        }

        // Total
        $sheet->setCellValue('D' . $row, 'Total:');
        $sheet->setCellValue('E' . $row, '=SUM(E7:E' . ($row - 1) . ')');
        $sheet->setCellValue('F' . $row, '=SUM(F7:F' . ($row - 1) . ')');
        $sheet->setCellValue('G' . $row, '=SUM(G7:G' . ($row - 1) . ')');

        // Save Excel file
        $writer = new Xlsx($spreadsheet);
        $filename = 'Histori_Barang_Masuk_' . date('YmdHis') . '.xlsx';
        $writer->save($filename);

        // Download file
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="' . $filename . '"');
        header('Cache-Control: max-age=0');

        $writer->save('php://output');
    }


}
