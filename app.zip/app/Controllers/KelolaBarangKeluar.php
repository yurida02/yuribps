<?php


namespace App\Controllers; // Namespace controller yang digunakan adalah App\Controllers

use Dompdf\Dompdf; //pdf
use Dompdf\Options; //konfigurasi dompdf
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx; //linbaryexel
use App\Models\BarangKeluarModel; // Import barangKeluarModel
use App\Models\BarangModel; // Import barangModel
use App\Controllers\BaseController;

class KelolaBarangKeluar extends BaseController // Tambahkan extends BaseController
{

    protected $BarangKeluarModel; // Tambahkan variabel barangKeluarModel

    public function __construct()
    {
        date_default_timezone_set('Asia/Makassar');
        $this->BarangKeluarModel = new BarangKeluarModel(); // Tambahkan barangKeluarModel ke constructor
    }

    public function index() // Tambahkan fungsi index
    {
        $data = [
            'title' => 'Kelola Barang Keluar', // Judul Halaman
            'barang_keluar' => $this->BarangKeluarModel->getBarangKeluar(), // Ambil data dari function getbarangKeluar di barangKeluarModel
            'jenis_barang' => $this->BarangKeluarModel->getJenisBarang(), // Ambil data dari function getJenisbarang di barangKeluarModel
            'barang' => $this->BarangKeluarModel->getBarang(), // Ambil data dari functaion getbarang di barangKeluarModel

        ];

        return view('kelola_barang_keluar/index', $data); // Tampilkan view kelola_barang_keluar/index.php dengan membawa data dari variabel $data
    }

    public function simpan() // Tambahkan fungsi simpan
    {
        $validationRules = [
            'id_barang' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Nama barang harus diisi.'
                ]
            ],
            'id_jenis' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Jenis barang harus diisi.'
                ]
            ],
            'jumlah' => [
                'rules' => 'required|numeric|greater_than[0]',
                'errors' => [
                    'required' => 'Jumlah barang harus diisi.',
                    'numeric' => 'Jumlah barang harus berupa angka.',
                    'greater_than' => 'Jumlah barang harus lebih dari 0.'
                ]
            ]
        ]; // Atur validasi form

        // Ambil data barang berdasarkan id_barang
        $barangModel = new BarangModel(); // pbo enskapsulasi // Buat objek dari barangModel
        $barangData = $barangModel->find($this->request->getVar('id_barang')); // Ambil data barang berdasarkan id_barang

        if (!$this->validate($validationRules)) {
            return redirect()->to('/barang-keluar')->withInput()->with('validation', $this->validator);
        } // Jika validasi gagal, kembali ke halaman barang-keluar

        // Ambil nilai id_jenis dari formulir atau sumber data
        $idJenisBarang = $this->request->getVar('id_jenis');

        // Kurangi stok barang berdasarkan jumlah yang keluar
        $stokBaru = $barangData['stok'] - $this->request->getVar('jumlah');

        // Simpan perubahan stok ke dalam tabel barang
        $barangModel->update($this->request->getVar('id_barang'), ['stok' => $stokBaru]);

        // Simpan data ke dalam tabel barang_keluar
        $this->BarangKeluarModel->save([
            'id_barang' => $this->request->getVar('id_barang'),
            'id_jenis' => $idJenisBarang,
            'tanggal_keluar' => date('Y-m-d H:i:s'),
            'jumlah' => $this->request->getVar('jumlah'),
            'total_harga' => $this->request->getVar('total_harga')
        ]); // Simpan data ke dalam tabel barang_keluar


        return redirect()->to('/barang-keluar')->with('pesan', 'Data Berhasil Ditambahkan'); // Kembali ke halaman barang-keluar
    }

    public function hapus($id)
    {
        // Ambil data barang keluar berdasarkan id_barang_keluar
        $barangKeluarData = $this->BarangKeluarModel->find($id);

        if ($barangKeluarData) {
            // Kembalikan stok barang
            $barangModel = new BarangModel();
            $barangData = $barangModel->find($barangKeluarData['id_barang']);

            // Perbarui stok barang sesuai dengan jumlah barang keluar
            $barangModel->update($barangKeluarData['id_barang'], [
                'stok' => $barangData['stok'] + $barangKeluarData['jumlah']
            ]);

            // Hapus data barang keluar
            $this->BarangKeluarModel->delete($id);

            session()->setFlashdata('pesan', 'Data Berhasil Dihapus dan Stok Telah Dikembalikan');
        } else {
            session()->setFlashdata('pesan', 'Gagal Menghapus Data');
        }

        return redirect()->to('/barang-keluar');
    }

    public function cetakPdf()
    {

        $tanggalawal = $this->request->getPost('tanggalawal');
        $tanggalakhir = $this->request->getPost('tanggalakhir');

        $data = [
            'barang_keluar' => $this->BarangKeluarModel->filterdatatanggal($tanggalawal, $tanggalakhir),

        ]; // Data yang akan dikirim ke view 



        // Buat objek Dompdf
        $options = new Options(); // Set options baru untuk Dompdf 
        $options->set('isHtml5ParserEnabled', true); // Aktifkan parser HTML5 
        $options->set('isPhpEnabled', true); // Aktifkan PHP parser 

        $dompdf = new Dompdf($options); // Instansiasi objek Dompdf baru 

        // Render HTML ke PDF
        $html = view('kelola_barang_keluar/cetak_pdf', $data); // Get output html 
        $dompdf->loadHtml($html); // Parse html ke dalam DOMpdf 
        $dompdf->setPaper('A4', 'portrait'); // Set paper dan orientasi custom 
        $dompdf->render(); // Render html menjadi PDF

        // Output PDF ke browser
        $dompdf->stream('histori_barang_keluar.pdf', ['Attachment' => 0]);
    }

    public function cetakExcel()
    {
        $barangKeluar = $this->BarangKeluarModel->getBarangKeluar();

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();


        // Data
        $sheet->setCellValue('A6', 'No');
        $sheet->setCellValue('B6', 'Nama Barang');
        $sheet->setCellValue('C6', 'Jumlah');
        $sheet->setCellValue('D6', 'Tanggal Keluar');
        $sheet->setCellValue('E6', 'Jumlah');
        $sheet->setCellValue('G6', 'Total Harga');

        $row = 7;
        $no = 1;
        foreach ($barangKeluar as $data) {
            $sheet->setCellValue('A' . $row, $no);
            $sheet->setCellValue('B' . $row, $data['nama_barang']);
            $sheet->setCellValue('C' . $row, $data['jumlah']);
            $sheet->setCellValue('D' . $row, date('d-m-Y H:i:s', strtotime($data['tanggal_keluar'])));
            $sheet->setCellValue('E' . $row, $data['jumlah']);
            $sheet->setCellValue('G' . $row, $data['total_harga']);

            $row++;
            $no++;
        }

        // Total
        $sheet->setCellValue('D' . $row, 'Total:');
        $sheet->setCellValue('E' . $row, '=SUM(E7:E' . ($row - 1) . ')');
        $sheet->setCellValue('G' . $row, '=SUM(G7:G' . ($row - 1) . ')');

        // Save Excel file
        $writer = new Xlsx($spreadsheet);
        $filename = 'Histori_Barang_Keluar_' . date('YmdHis') . '.xlsx';
        $writer->save($filename);

        // Download file
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="' . $filename . '"');
        header('Cache-Control: max-age=0');

        $writer->save('php://output');
    }


}
