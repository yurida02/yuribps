<?php

namespace App\Controllers;

use App\Models\JenisBarangModel;
use App\Controllers\BaseController;

class JenisBarang extends BaseController
{

    protected $jenisBarangModel;

    public function __construct()
    {
        $this->jenisBarangModel = new JenisBarangModel();
    }

    // function untuk menampilkan data jenis bararang 
    public function index()
    {
        $data['title'] = 'Kelola Jenis Barang';
        $data['jenis_barang'] = $this->jenisBarangModel->findAll();       
        return view('jenis_barang/index', $data);
    }

    // function untuk menampilkan form tambah data jenis barang
    public function tambah()
    {
        $data = [
            'title' => 'Tambah Data Jenis Barang',
            'validation' => \Config\Services::validation()

        ];

        return view('jenis_barang/tambah', $data);

    }

    public function simpan()
    {

        // jika data sudah ada maka akan menampilkan pesan error
        if ($this->jenisBarangModel->where(['jenis_barang' => $this->request->getVar('jenis_barang')])->first()) {
            session()->setFlashdata('errors', ['jenis_barang' => 'Jenis Barang Sudah Ada']);
            return redirect()->back()->withInput();
        } else {
            session()->remove('errors');
        }

        // validasi inputan
        $validationRules = [
            'jenis_barang' => [
                'rules' => 'required|alpha',
                'errors' => [
                    'required' => 'Kolom Jenis Barang Harus Diisi',
                    'alpha' => 'Kolom Jenis Barang Hanya Boleh Berisi Huruf',
                ],
            ]
        ];

        if (!$this->validate($validationRules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $this->jenisBarangModel->save([
            'jenis_barang' => $this->request->getVar('jenis_barang')
        ]);

        session()->setFlashdata('pesan', 'Data Jenis Barang Berhasil Ditambahkan');
        return redirect()->to('/jenis-barang');
    }

    // function untuk menampilkan form edit data jenis barang
    public function edit($id)
    {
        $data = [
            'title' => 'Edit Data Jenis Barang',
            'validation' => \Config\Services::validation(),
            'jenis_barang' => $this->jenisBarangModel->find($id)
        ];

        return view('jenis_barang/edit', $data);
    }
    // function untuk mengupdate data jenis barang
    public function update($id)
    {
        $validationRules = [
            'jenis_barang' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kolom Jenis Barang Harus Diisi',
                ],
            ]
        ];
        if (!$this->validate($validationRules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        } else {
            session()->remove('errors');
        }
        $jenis_barang = $this->request->getVar('jenis_barang');
        $data = [
            'jenis_barang' => $jenis_barang
        ];
        $this->jenisBarangModel->update($id, $data);
        session()->setFlashdata('pesan', 'Data Jenis Barang Berhasil Diubah');
        return redirect()->to('/jenis-barang');
    }

    // function untuk menghapus data jenis barang
    public function hapus($id)
    {
        $this->jenisBarangModel->delete($id);
        session()->setFlashdata('pesan', 'Data Jenis Barang Berhasil Dihapus');
        return redirect()->to('/jenis-barang');
    }
}