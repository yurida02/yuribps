<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\BarangModel;

class KelolaBarang extends BaseController
{
    protected $barangModel;

    public function __construct()
    {
        $this->barangModel = new BarangModel();
    }

    public function index()
    {
        $data['title'] = 'Kelola Barang';
        $data['barang'] = $this->barangModel->getBarang();
        return view('kelola_barang/index', $data);
    }

    public function tambah()
    {
        $data = [
            'title' => 'Tambah Data Barang',
            'validation' => \Config\Services::validation(),
            'jenis_barang' => $this->barangModel->getJenisBarang(),
        ];
        return view('kelola_barang/tambah', $data);
    }

    public function simpan()
    {
        // Cek apakah nama barang sudah ada
        if ($this->barangModel->where(['nama_barang' => $this->request->getVar('nama_barang')])->first()) {
            session()->setFlashdata('nama_barang', 'Nama Barang Sudah Ada');
            return redirect()->back()->withInput();
        } else {
            session()->remove('errors');
        }

        // Validasi inputan
        $validationRules = [
            'id_jenis' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kolom Jenis Barang Harus Diisi',
                ],
            ],
            'nama_barang' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kolom Nama Barang Harus Diisi',
                ],
            ],
            'harga' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kolom Harga Harus Diisi',
                ],
            ],
            'harga_jual' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kolom Harga Jual Harus Diisi',
                ],
            ],
        ];

        if (!$this->validate($validationRules)) {
            session()->setFlashdata('pesan', 'Data barang belum disi');
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        // Simpan data barang
        $this->barangModel->save([
            'id_jenis' => $this->request->getVar('id_jenis'),
            'kode_barang' => $this->request->getVar('kode_barang'),
            'nama_barang' => $this->request->getVar('nama_barang'),
            'harga' => str_replace('.', '', preg_replace('/[^0-9.]/', '', $this->request->getVar('harga'))), // Harga disimpan tanpa format Rp
            'harga_jual' => str_replace('.', '', preg_replace('/[^0-9.]/', '', $this->request->getVar('harga_jual'))), // Harga jual disimpan tanpa format Rp
            'stok' => $this->request->getVar('stok'),
        ]);

        session()->setFlashdata('pesan', 'Data Berhasil Ditambahkan');
        return redirect()->to('/kelola-barang');
    }

    public function edit($id)
    {
        $data = [
            'title' => 'Edit Data Barang',
            'validation' => \Config\Services::validation(),
            'jenis_barang' => $this->barangModel->getJenisBarang(),
            'barang' => $this->barangModel->find($id),
        ];

        return view('kelola_barang/edit', $data);
    }

    public function update($id)
    {
        // Validasi inputan
        $validationRules = [
            'id_jenis' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kolom Jenis Barang Harus Diisi',
                ],
            ],
            'nama_barang' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kolom Nama Barang Harus Diisi',
                ],
            ],
            'harga' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kolom Harga Harus Diisi',
                ],
            ],
            'harga_jual' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kolom Harga Jual Harus Diisi',
                ],
            ],
            'stok' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kolom Stok Harus Diisi',
                ],
            ],
        ];

        if (!$this->validate($validationRules)) {
            return redirect()->to('/kelola-barang/edit/' . $id)->withInput();
        }

        // Ambil data dari request
        $id_jenis = $this->request->getVar('id_jenis');
        $kode_barang = $this->request->getVar('kode_barang');
        $nama_barang = $this->request->getVar('nama_barang');
        $harga = str_replace('.', '', preg_replace('/[^0-9.]/', '', $this->request->getVar('harga'))); // Harga disimpan tanpa format Rp
        $harga_jual = str_replace('.', '', preg_replace('/[^0-9.]/', '', $this->request->getVar('harga_jual'))); // Harga jual disimpan tanpa format Rp
        $stok = $this->request->getVar('stok');

        // Data yang akan diupdate
        $data = [
            'id_jenis' => $id_jenis,
            'kode_barang' => $kode_barang,
            'nama_barang' => $nama_barang,
            'harga' => $harga,
            'harga_jual' => $harga_jual,
            'stok' => $stok,
        ];

        // Lakukan update data barang
        $this->barangModel->update($id, $data);

        session()->setFlashdata('pesan', 'Data Berhasil Diubah');
        return redirect()->to('/kelola-barang');
    }

    public function hapus($id)
    {
        $this->barangModel->delete($id);
        session()->setFlashdata('pesan', 'Data Berhasil Dihapus');
        return redirect()->to('/kelola-barang');
    }

    public function cetakPdf()
    {
        // Ambil data barang dari model
        $data['barang'] = $this->barangModel->getBarang();

        // Konfigurasi dompdf
        $options = new \Dompdf\Options();
        $options->set('isHtml5ParserEnabled', true);
        $options->set('isPhpEnabled', true);

        // Inisialisasi dompdf dengan konfigurasi
        $dompdf = new \Dompdf\Dompdf($options);

        // Load HTML ke dompdf
        $html = view('kelola_barang/cetak_pdf', $data);
        $dompdf->loadHtml($html);

        // Tentukan ukuran kertas dan orientasi
        $dompdf->setPaper('A4', 'portrait');

        // Render PDF (buat file atau keluarkan ke browser)
        $dompdf->render();

        // Keluarkan PDF ke browser
        $dompdf->stream('cetak_barang.pdf', array('Attachment' => 0));
    }

    public function cetakExcel()
    {
        // Ambil data barang dari model
        $barang = $this->barangModel->getBarang();

        // Inisialisasi spreadsheet
        $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        // Judul kolom
        $sheet->setCellValue('A1', 'No');
        $sheet->setCellValue('B1', 'Kode Barang');
        $sheet->setCellValue('C1', 'Jenis Barang');
        $sheet->setCellValue('D1', 'Nama Barang');
        $sheet->setCellValue('E1', 'Harga');
        $sheet->setCellValue('F1', 'Harga Jual');
        $sheet->setCellValue('G1', 'Stok');

        // Data
        $row = 2;
        $no = 1;
        foreach ($barang as $data) {
            $sheet->setCellValue('A' . $row, $no++);
            $sheet->setCellValue('B' . $row, $data['kode_barang']);
            $sheet->setCellValue('C' . $row, $data['jenis_barang']);
            $sheet->setCellValue('D' . $row, $data['nama_barang']);
            $sheet->setCellValue('E' . $row, $data['harga']);
            $sheet->setCellValue('F' . $row, $data['harga_jual']);
            $sheet->setCellValue('G' . $row, $data['stok']);
            $row++;
        }

        // Simpan ke file
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        $filename = 'data_barang_' . date('YmdHis') . '.xlsx';
        $writer->save($filename);

        // Download file
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="' . $filename . '"');
        header('Cache-Control: max-age=0');

        $writer->save('php://output');
        exit;
    }
}
