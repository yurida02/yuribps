<?php

namespace App\Controllers;

use App\Models\SurveiModel;

class Survei extends BaseController
{
    protected $surveiModel;

    public function __construct()
    {
        $this->surveiModel = new SurveiModel();
    }

    // Menampilkan daftar survei
    public function index()
    {
        $session = session();

        // Pengecekan peran pengguna
        if ($session->get('role') !== 'Admin' && $session->get('role') !== 'Supervisor' && $session->get('role') !== 'Penginput' && $session->get('role') !== 'Administrasi') {

            return redirect()->to('/unauthorized')->with('error', 'Anda tidak memiliki akses untuk halaman tersebut.');
        }
        
        $data = [
            'title' => 'Survei',
            'survei' => $this->surveiModel->findAll() // Mengambil data survei dari model
        ];

        return view('survei/index', $data); // Mengirim data ke tampilan
    }

    // Menampilkan form tambah survei
    public function tambah()
    {
        $data = [
            'title' => 'Tambah Survei',
            'validation' => \Config\Services::validation()
        ];

        return view('survei/tambah', $data);
    }

    // Menyimpan data survei baru
    public function simpan()
    {
        // Validasi input
        if (!$this->validate([
            'sobat_id' => 'required',
            'nama' => 'required',
            'kec' => 'required',
            'alamat' => 'required',
            'status' => 'required',
            'anggaran' => 'required',
            'keg' => 'required',
            'uraian' => 'required',
            'vol' => 'required|numeric',
            'satuan' => 'required',
            'harga' => 'required|numeric',
            'jumlah' => 'required|numeric',
            'bulan' => 'required',
            'konfirm' => 'required',
        ])) {
            return redirect()->to('/survei/tambah')->withInput()->with('validation', \Config\Services::validation());
        }

        // Mengambil data dari input form
        $data = [
            'sobat_id' => $this->request->getPost('sobat_id'),
            'nama' => $this->request->getPost('nama'),
            'kec' => $this->request->getPost('kec'),
            'alamat' => $this->request->getPost('alamat'),
            'status' => $this->request->getPost('status'),
            'anggaran' => $this->request->getPost('anggaran'),
            'keg' => $this->request->getPost('keg'),
            'uraian' => $this->request->getPost('uraian'),
            'vol' => $this->request->getPost('vol'),
            'satuan' => $this->request->getPost('satuan'),
            'harga' => $this->request->getPost('harga'),
            'jumlah' => $this->request->getPost('jumlah'),
            'bulan' => $this->request->getPost('bulan'),
            'konfirm' => $this->request->getPost('konfirm'),
        ];

        // Simpan data survei baru ke database
        $this->surveiModel->insert($data);

        // Mengarahkan kembali ke halaman daftar dengan pesan sukses
        session()->setFlashdata('pesan', 'Data survei berhasil ditambahkan');
        return redirect()->to('/survei');
    }

    // Menampilkan form edit survei
public function edit($sobat_id)
{
    // Ambil data survei berdasarkan sobat_id
    $survei = $this->surveiModel->find($sobat_id);

    // Cek apakah survei ditemukan
    if (!$survei) {
        return redirect()->to('/survei')->with('error', 'Data survei tidak ditemukan.');
    }

    $data = [
        'title' => 'Ubah Survei',
        'validation' => \Config\Services::validation(),
        'survei' => $survei // Kirim data survei ke tampilan
    ];

    return view('survei/edit', $data); // Pastikan Anda memiliki view edit untuk menampilkan form
}

// Menyimpan perubahan data survei
public function update($sobat_id)
{
    // Validasi input
    if (!$this->validate([
        'nama' => 'required',
        'kec' => 'required',
        'alamat' => 'required',
        'status' => 'required',
        'anggaran' => 'required',
        'keg' => 'required',
        'uraian' => 'required',
        'vol' => 'required|numeric',
        'satuan' => 'required',
        'harga' => 'required|numeric',
        'jumlah' => 'required|numeric',
        'bulan' => 'required',
        'konfirm' => 'required',
    ])) {
        return redirect()->to('/survei');
    }

    // Mengambil data dari input form
    $data = [
        'nama' => $this->request->getPost('nama'),
        'kec' => $this->request->getPost('kec'),
        'alamat' => $this->request->getPost('alamat'),
        'status' => $this->request->getPost('status'),
        'anggaran' => $this->request->getPost('anggaran'),
        'keg' => $this->request->getPost('keg'),
        'uraian' => $this->request->getPost('uraian'),
        'vol' => $this->request->getPost('vol'),
        'satuan' => $this->request->getPost('satuan'),
        'harga' => $this->request->getPost('harga'),
        'jumlah' => $this->request->getPost('jumlah'),
        'bulan' => $this->request->getPost('bulan'),
        'konfirm' => $this->request->getPost('konfirm'),
    ];

    if ($this->surveiModel->update($sobat_id, $data)) {
        return redirect()->to('/survei')->with('success', 'Survei berhasil diubah.');
    } else {
        return redirect()->to('/survei')->with('error', 'Gagal mengubah data. Silakan coba lagi.');
    }
}
    public function hapus($sobat_id)
    {
        $this->surveiModel->delete($sobat_id);
        return redirect()->to('/survei')->with('success', 'Survei berhasil dihapus.');
    }

    public function cetakPdf()
{
    // Ambil data survei dari model
    $data['survei'] = $this->surveiModel->findAll();

    // Konfigurasi dompdf
    $options = new \Dompdf\Options();
    $options->set('isHtml5ParserEnabled', true);
    $options->set('isPhpEnabled', true);

    // Inisialisasi dompdf dengan konfigurasi
    $dompdf = new \Dompdf\Dompdf($options);

    // Load HTML ke dompdf
    $html = view('survei/cetak_pdf', $data); // Ganti dengan tampilan yang sesuai
    $dompdf->loadHtml($html);

    // Tentukan ukuran kertas dan orientasi
    $dompdf->setPaper('A4', 'portrait');

    // Render PDF (buat file atau keluarkan ke browser)
    $dompdf->render();

    // Keluarkan PDF ke browser
    $dompdf->stream('cetak_survei.pdf', array('Attachment' => 0));
}

public function cetakExcel()
{
    // Ambil data survei dari model
    $survei = $this->surveiModel->findAll();

    // Inisialisasi spreadsheet
    $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();

    // Judul kolom
    $sheet->setCellValue('A1', 'No');
    $sheet->setCellValue('B1', 'Sobat ID');
    $sheet->setCellValue('C1', 'Nama');
    $sheet->setCellValue('D1', 'Kecamatan');
    $sheet->setCellValue('E1', 'Alamat');
    $sheet->setCellValue('F1', 'Status');
    $sheet->setCellValue('G1', 'Anggaran');
    $sheet->setCellValue('H1', 'Kegiatan');
    $sheet->setCellValue('I1', 'Uraian');
    $sheet->setCellValue('J1', 'Volume');
    $sheet->setCellValue('K1', 'Satuan');
    $sheet->setCellValue('L1', 'Harga');
    $sheet->setCellValue('L1', 'jumlah');
    $sheet->setCellValue('M1', 'Bulan');
    $sheet->setCellValue('N1', 'Konfirmasi');

    // Data
    $row = 2;
    $no = 1;
    foreach ($survei as $data) {
        $sheet->setCellValue('A' . $row, $no++);
        $sheet->setCellValue('B' . $row, $data['sobat_id']);
        $sheet->setCellValue('C' . $row, $data['nama']);
        $sheet->setCellValue('D' . $row, $data['kec']);
        $sheet->setCellValue('E' . $row, $data['alamat']);
        $sheet->setCellValue('F' . $row, $data['status']);
        $sheet->setCellValue('G' . $row, $data['anggaran']);
        $sheet->setCellValue('H' . $row, $data['keg']);
        $sheet->setCellValue('I' . $row, $data['uraian']);
        $sheet->setCellValue('J' . $row, $data['vol']);
        $sheet->setCellValue('K' . $row, $data['satuan']);
        $sheet->setCellValue('L' . $row, $data['harga']);
        $sheet->setCellValue('L' . $row, $data['jumlah']);
        $sheet->setCellValue('M' . $row, $data['bulan']);
        $sheet->setCellValue('N' . $row, $data['konfirm']);
        $row++;
    }

    // Simpan ke file
    $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
    $filename = 'data_survei_' . date('YmdHis') . '.xlsx';
    $writer->save($filename);

    // Download file
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="' . $filename . '"');
    header('Cache-Control: max-age=0');

    $writer->save('php://output');
    exit;
}
}