<?php

namespace App\Models;

use CodeIgniter\Model;

class BarangMasukModel extends Model //extends syintax inheritens turunan class yang mempunyai anak class 
{

    protected $table = 'barang_masuk'; //protected hak akses class (enkapsulasi ) digunakan untuk menentukan nama tabel database 
    protected $primaryKey = 'id_barang_masuk';
    protected $useAutoIncrement = true;
    protected $allowedFields = ['id_barang', 'tanggal_masuk', 'jumlah',  'nominal_harga', 'total_harga',];
    //allow fields digunakan untuk menetapkan daftar kolom database yang diizinkan untuk diisi atau diupdate melalui operasi CRUD 
    public function BarangMasuk() //method function barang masuk dengan enkapsulasi hak akses class public
    {
        return $this->db->table('barang_masuk')
            ->join('barang', 'barang.id_barang = barang_masuk.id_barang')
           
            ->get()->getResultArray();
    }


   

    public function jumlahBarangMasuk() //method jumlah barang masuk dengan enkapsulasi hak akses class public
    {
        return $this->db->table('barang_masuk')
          
            ->countAllResults(); //menghitung jumlah baris atau hasil yang akan dikembalikan oleh suatu query tanpa mengeksekusi query secara penuh.
    }

    public function getJenisBarang() //method mengambil dari tabel jenis barang dengan enkapsulasi hak akses class public
    {
        return $this->db->table('jenis_barang')->get()->getResultArray();
    }

    public function getBarang() //method mengambil dari tabel barang dengan enkapsulasi hak akses class public
    {
        return $this->db->table('barang')->get()->getResultArray();
    }

    
    public function filterdatatanggal($tanggalawal = null, $tanggalakhir = null) //method untuk memfilter data tanggal awal dan akhir pada laporan dengan enkapsulasi hak akses class public
    {
        $builder = $this->db->table('barang_masuk'); // query builder dari tabel barang_masuk
        $builder = $this->db->table('barang_masuk')
            ->join('barang', 'barang.id_barang = barang_masuk.id_barang');

        if ($tanggalawal && $tanggalakhir) {
            $builder->where('tanggal_masuk >=', $tanggalawal . ' 00:00:00')
                ->where('tanggal_masuk <=', $tanggalakhir . ' 23:59:59');
        }

        return $builder->get()->getResultArray(); //mengeksekusi query yang dibangun dengan $builder, mengambil hasilnya, dan mengembalikan hasil tersebut dalam bentuk array asosiatif.
    }
}