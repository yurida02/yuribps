<?php

namespace App\Models;

use CodeIgniter\Model;

class BarangModel extends Model
{
    protected $table = 'barang';
    protected $primaryKey = 'id_barang';
    protected $useAutoIncrement = true;
    protected $allowedFields = ['id_jenis', 'kode_barang', 'nama_barang', 'harga', 'harga_jual', 'stok','keuntungan' ];

    protected function Keuntungan(array $data)
    {
        if (isset($data['data']['harga_jual']) && isset($data['data']['harga'])) {
            $data['data']['keuntungan'] = $data['data']['harga_jual'] - $data['data']['harga'];
        }
        
        return $data;
    }
    public function getBarang()
    {
        return $this->db->table('barang')
            ->join('jenis_barang', 'jenis_barang.id_jenis = barang.id_jenis')
            ->get()->getResultArray();
    }

    public function jumlahBarang()
    {
        return $this->db->table('barang')->countAllResults();
    }

    public function find($id = null)
    {
        return $this->db->table('barang')
            ->join('jenis_barang', 'jenis_barang.id_jenis = barang.id_jenis')
            ->where(['id_barang' => $id])
            ->get()->getRowArray();
    }

    public function getJenisBarang()
    {
        return $this->db->table('jenis_barang')->get()->getResultArray();
    }

}