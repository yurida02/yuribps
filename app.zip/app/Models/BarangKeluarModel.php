<?php

namespace App\Models;

use CodeIgniter\Model;

class BarangKeluarModel extends Model
{
    protected $table = 'barang_keluar';
    protected $primaryKey = 'id_barang_keluar';
    protected $useAutoIncrement = true;
    protected $allowedFields = [ 'id_barang', 'id_jenis', 'id_barang_masuk', 'tanggal_keluar', 'jumlah', 'total_harga'];

    public function getBarangKeluar()
    {
        // join antara table barang dan jenis barang
        return $this->db->table('barang_keluar')
            ->join('barang', 'barang.id_barang = barang_keluar.id_barang')
            ->join('jenis_barang', 'jenis_barang.id_jenis = barang_keluar.id_jenis')
            ->get()->getResultArray();
    }


    public function getBarangKeluarSementara()
    {
        // join antara table barang dan jenis barang
        return $this->db->table('barang_keluar')
            ->join('barang', 'barang.id_barang = barang_keluar.id_barang')
            ->join('jenis_barang', 'jenis_barang.id_jenis = barang_keluar.id_jenis')
            ->get()->getResultArray();
    }

    public function getDataForChart()
    {
        // Ambil data dari database atau sumber data lainnya
        // Misalnya, ambil data barang keluar dari database
        $result = $this->db->table('barang_keluar')
            ->select('MONTH(tanggal_keluar) as month, COUNT(*) as count')
            ->groupBy('month')
            ->get()
            ->getResult();

        // Inisialisasi array untuk labels (bulan) dan values (jumlah barang keluar)
        $labels = [];
        $values = [];

        // Isi array berdasarkan data yang diambil dari database
        foreach ($result as $row) {
            $labels[] = date('M', mktime(0, 0, 0, $row->month, 1));
            $values[] = $row->count;
        }

        // Buat array yang akan dikembalikan
        $chartData = [
            'labels' => $labels,
            'values' => $values
        ];

        return $chartData;
    }

    public function jumlahBarangKeluar()
    {
        return $this->db->table('barang_keluar')->countAllResults();
    }

    public function getBarang()
    {
        return $this->db->table('barang')
            ->select('barang.id_barang, barang.nama_barang, barang.id_jenis, barang.kode_barang, barang.harga_jual, barang.stok')
            ->join('jenis_barang', 'jenis_barang.id_jenis = barang.id_jenis')
            ->get()->getResultArray();
    }
    public function getJenisBarang()
    {
        return $this->db->table('jenis_barang')->get()->getResultArray();
    }

    public function filterdatatanggal($tanggalawal = null, $tanggalakhir = null)
    {
        $builder = $this->db->table('barang_keluar'); // query builder dari tabel barang_masuk
        $builder = $this->db->table('barang_keluar')
            ->join('barang', 'barang.id_barang = barang_keluar.id_barang');

        if ($tanggalawal && $tanggalakhir) {
            $builder->where('tanggal_masuk >=', $tanggalawal . ' 00:00:00')
                ->where('tanggal_masuk <=', $tanggalakhir . ' 23:59:59');
        }

        return $builder->get()->getResultArray();
    }

}
