<?= $this->extend('templates/main') ?>
<?= $this->section('content') ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">
                        <?= $title; ?>
                    </h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">
                            <?= $title; ?>
                        </li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card-header">
                        <?php if (session('pesan')): ?>
                            <div class="alert alert-success alert-dismissible mt-3">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                <?= session('pesan'); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="card">
                        <!-- /.card-header -->
                        <div class="card-body">
                            <!-- Button trigger modal -->
                            <button type="button" class="btn btn-primary" data-toggle="modal" 
                                data-target="#staticBackdrop"> <!--button tambah data barang-->
                                Tambah Data Barang Masuk
                            </button>
                            <a href="/barang-masuk/cetakexcel" class="btn btn-success mb-2"><i  
                                    class="fas fa-file-excel"></i></a> <!--button excel-->
                            <div class="float-right">
                                <form action="/barang-masuk/cetakpdf" method="post">
                                    <label for="tanggalawal">Tanggal Awal:</label>
                                    <input type="date" name="tanggalawal">

                                    <label for="tanggalakhir">Tanggal Akhir:</label>
                                    <input type="date" name="tanggalakhir">

                                    <button type="submit" class="btn btn-warning"><i 
                                            class="fas fa-file-pdf"></i></button> <!--button cetak pdf-->
                                </form>
                            </div>

                            <table id="example2" class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama Barang</th>
                                        <th>Tanggal</th>
                                        <th>Jumlah</th>
                                        <th>Harga Awal</th>
                                        <th>Total Harga</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no = 1;
                                    $totalHargaSeluruh = 0;
                                    foreach ($barang_masuk as $oms): ?> 
                                        <tr>
                                            <td>
                                                <?= $no++; ?>
                                            </td>
                                            <td>
                                                <?= $oms['nama_barang']; ?>
                                            </td>
                                            <td>
                                                <?= date('d-m-Y', strtotime($oms['tanggal_masuk'])); ?>
                                            </td>
                                            <td>
                                                <?= $oms['jumlah']; ?>
                                            </td>
                                           
                                            <td>
                                                <?= $oms['harga_jual']; ?>
                                            </td>
                                            <td>
                                                <?= $oms['total_harga']; ?>
                                            </td>
                                            <td>
                                                <a href="/barang-masuk/hapus/<?= $oms['id_barang_masuk']; ?>"
                                                    class="btn btn-danger btn-sm" 
                                                    onclick="return confirm('Apakah Anda Yakin Ingin Menghapus Data Ini ?');">
                                                    <i class="fas fa-trash"></i> <!--button hapus-->
                                                </a>
                                            </td>
                                            <?php
                                            $totalHargaSeluruh += $oms['total_harga']; // Akumulasi total harga
                                                endforeach;
                                            ?>
                                        </tr>
                                </tbody>
                            </table>
                            <?php
                            // Format total harga seluruh sebagai ribuan dalam bahasa Indonesia
                            $totalHargaSeluruhFormatted = number_format($totalHargaSeluruh, 0, ',', '.');

                            // Menambahkan teks "Rp" di depan angka
                            $totalHargaSeluruhFormatted = 'Rp ' . $totalHargaSeluruhFormatted;
                            ?>
                        </div>
                    </div>
                    <!-- bold -->
                    <div class="col-12">
                        <h5>Total Harga Seluruh:
                            <?= $totalHargaSeluruhFormatted; ?>
                        </h5>
                    </div>
                </div>
            </div>
    </section>

    <!-- Modal -->
    <div class="modal fade bd-example-modal-lg" id="staticBackdrop" data-backdrop="static" tabindex="-1" role="dialog"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">
                        <?= $title; ?>
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <!--button close-->
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- form group -->
                    <form action="/barang-masuk/simpan" method="post" onsubmit="return validateForm();">
                        <div class="form-group">
                            <label for="">Nama Barang</label>
                            <button type="button" class="btn btn-primary btn-sm ml-2" data-toggle="modal" data-target="#modalDalamModal">
                                <i class="fas fa-plus"></i>
                            </button>
                            <select name="id_barang" id="id_barang" class="form-control" required>
                                <option value="">Pilih Barang</option>
                                <?php foreach ($barang as $o): ?>
                                    <option value="<?= $o['id_barang']; ?>" data-kode="<?= $o['harga']; ?>">
                                        <?= $o['nama_barang']; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="">Jumlah Barang</label>
                                <input type="number" class="form-control" name="jumlah" oninput="validateInput(this);" required>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="">Nominal Harga (SATUAN)</label>
                                <input type="text" class="form-control" id="nominal_harga" name="nominal_harga" required>
                            </div>
                        </div>

                        <script>
                            function validateInput(input) {
                                // Menghapus karakter "-" dari masukan pengguna
                                input.value = input.value.replace(/-/g, '');

                                // Hanya mengizinkan karakter angka
                                input.value = input.value.replace(/\D/g, '');

                                // Jika Anda ingin mengizinkan desimal, Anda dapat menggunakan regex ini:
                                // input.value = input.value.replace(/[^\d.]/g, '');
                            }

                            // Mendengarkan perubahan pada dropdown "Nama Barang"
                            document.getElementById("id_barang").addEventListener("change", function () {
                                // Mendapatkan pilihan yang dipilih
                                var selectedOption = this.options[this.selectedIndex];

                                // Mengisi nilai "Kode Barang" dengan data kode dari pilihan yang dipilih
                                document.getElementById("nominal_harga").value = selectedOption.getAttribute("data-kode");
                            });

                            function calculateTotal() {
                                // Ambil nilai dari kolom jumlah
                                var jumlah = parseFloat(document.getElementsByName('jumlah')[0].value) || 0;

                                // Ambil nilai dari kolom nominal harga dan hilangkan separator ribuan
                                var nominalHarga = parseFloat(document.getElementById('nominal_harga').value.replace(/\./g, '').replace(/\,/g, '')) || 0;

                                // Hitung total perkalian
                                var total = jumlah * nominalHarga;

                                // Tampilkan hasil total tanpa pemisah ribuan
                                document.getElementById('total').value = total.toFixed(0);
                            }

                            var jumlahInput = document.getElementsByName('jumlah')[0];
                            jumlahInput.addEventListener('input', function () {
                                calculateTotal();
                            });

                            var hargaInput = document.getElementById('nominal_harga');
                            hargaInput.addEventListener('input', function (e) {
                                var unformatted = e.target.value.replace(/\./g, '').replace(/\,/g, '');
                                e.target.value = formatRupiah(unformatted);
                                calculateTotal();
                            });

                            function formatRupiah(angka) {
                                var number_string = angka.toString();
                                var split = number_string.split(',');
                                var sisa = split[0].length % 3;
                                var rupiah = split[0].substr(0, sisa);
                                var ribuan = split[0].substr(sisa).match(/\d{3}/gi);

                                if (ribuan) {
                                    separator = sisa ? '.' : '';
                                    rupiah += separator + ribuan.join('.');
                                }

                                rupiah = split[1] !== undefined ? rupiah + ',' + split[1] : rupiah;

                                return rupiah;
                            }

                            
                        </script>

                        <!-- Hasil perkalian -->
                        <div class="form-group col-md-6">
                            <label for="">Total</label>
                            <input type="text" class="form-control" id="total" name="total_harga" readonly>
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Submit</button> <!--button submit-->
                        </div>
                    </form>
                    <!-- Modal Kedua -->
                    <div class="modal fade" id="modalDalamModal" tabindex="-1" role="dialog"
                        aria-labelledby="modalDalamModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="modalDalamModalLabel">Tambah Data Barang</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <form action="/kelola-barang/simpan" method="post">
                                        <?= csrf_field(); ?> //melindungi keamanan form
                                        <div class="form-group">
                                            <label for="nama">Nama Jenis Barang</label>
                                            <select class="form-control" name="id_jenis_barang" id="id_jenis_barang" required>
                                                <option value="">-- Pilih Jenis Barang --</option>
                                                <?php foreach ($jenis_barang as $jo): ?>
                                                    <option value="<?= $jo['id_jenis']; ?>">
                                                        <?= $jo['jenis_barang']; ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                            <div class="invalid-feedback">
                                                <?= $validation->getError('id_jenis_barang'); ?>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label for="nama">Kode Barang</label>
                                            <input type="text"
                                                class="form-control <?= ($validation->hasError('kode_barang')) ? 'is-invalid' : ''; ?>"
                                                id="kode_barang" name="kode_barang" placeholder="Masukkan Kode Barang"
                                                value="<?= old('kode_barang', 'AR-' . str_pad(rand(1, 999), 3, '0', STR_PAD_LEFT)); ?>"
                                                pattern="AR-\d{3}" readonly>
                                            <div class="invalid-feedback">
                                                <?= $validation->getError('kode_barang'); ?>
                                            </div>
                                        </div>

                                        
                                        <div class="form-group">
                                            <label for="nama">Nama Barang</label>
                                            <input type="text"
                                                class="form-control <?= ($validation->hasError('nama_barang')) ? 'is-invalid' : ''; ?>"
                                                id="nama_barang" name="nama_barang" placeholder="Masukkan Nama Barang"
                                                value="<?= old('nama_barang'); ?>" required>
                                            <div class="invalid-feedback">
                                                <?= $validation->getError('nama_barang'); ?>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="harga">Harga</label>
                                            <input type="text"
                                                class="form-control <?= ($validation->hasError('harga')) ? 'is-invalid' : ''; ?>"
                                                id="harga" name="harga" placeholder="Masukkan Harga"
                                                value="<?= old('harga'); ?>" required>
                                            <div class="invalid-feedback">
                                                <?= $validation->getError('harga'); ?>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label for="harga">Harga Jual</label>
                                            <input type="text"
                                                class="form-control <?= ($validation->hasError('harga_jual')) ? 'is-invalid' : ''; ?>"
                                                id="harga_jual" name="harga_jual" placeholder="Masukkan Harga Jual"
                                                value="<?= old('harga_jual'); ?>" oninput="validateInput(this);" required>
                                            <div class="invalid-feedback">
                                                <?= $validation->getError('harga_jual'); ?>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label for="stok">Stok</label>
                                            <input type="text"
                                                class="form-control <?= ($validation->hasError('stok')) ? 'is-invalid' : ''; ?>"
                                                id="stok" name="stok" placeholder="Masukkan Stok"
                                                value="<?= old('stok'); ?>" oninput="validateInput(this);" required>
                                            <div class="invalid-feedback">
                                                <?= $validation->getError('stok'); ?>
                                            </div>
                                        </div>

                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                                            <button type="submit" class="btn btn-primary">Simpan</button> <!--button simpan-->
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Modal Kedua -->
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>  
