<!DOCTYPE html>
<html>

<head>
    <title>Laporan Barang Masuk</title>
    <!-- Gaya CSS disini jika diperlukan -->
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        .header {
            text-align: center;
        }

        .alamat {
            text-align: center;
            margin-bottom: 20px;
            border-bottom: 1px solid black;
        }

        .footer {
            margin-top: 20px;
            text-align: right;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table,
        th,
        td {
            border: 1px solid black;
        }

        th {
            padding: 10px;
            text-align: left;
            color: #fff;
            /* Menambahkan warna teks pada th */
            background-color: cornflowerblue;
            /* Menambahkan warna latar belakang pada th */
        }

        td {
            padding: 10px;
            text-align: left;
        }

        .total {
            font-weight: bold;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Angkringan HTS</h1>
    </div>

    <div class="alamat">
        <p>Jl. Ahmad Yani Angsau Kec. Pelaihari, Kab. Tanah Laut, Prov. Kalimantan Selatan</p>
    </div>

    <div class="footer">
        <p>Nomor Cetak:
            <?= date('YmdHis'); ?>
        </p>
    </div>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Barang</th>
                <th>Tanggal</th>
                <th>Jumlah</th>
                <th>Harga awal</th>
                <th>Harga jual</th>
                <th>Keuntungan</th>
            </tr>
        </thead>
        <tbody>
    <?php
    $no = 1;
    $totalJumlah = 0;
    $totalNominalHarga = 0;
    $totalHargaJualKumulatif = 0;
    $totalNominalHargaKumulatif = 0;
    $totalKeuntunganKeseluruhan = 0;
    ?>
    <?php foreach ($barang_masuk as $row): ?> //tag pembuka dari struktur pengulangan obat masuk foreach dalam PHP.
        <tr>
            <td><?= $no++; ?></td>
            <td><?= $row['nama_barang']; ?></td>
            <td><?= date('d-m-Y H:i:s', strtotime($row['tanggal_masuk'])); ?></td>
            <td><?= $row['jumlah']; ?></td>
            <td><?= $row['nominal_harga']; ?></td>
            <td><?= $row['harga_jual']; ?></td>
            <td><?= ($row['harga_jual'] - $row['nominal_harga']) * $row['jumlah']; ?></td>
        </tr>
        <?php
        $totalJumlah += $row['jumlah'];
        $totalNominalHarga += $row['nominal_harga'];
        $totalHargaJualKumulatif += $row['harga_jual'] * $row['jumlah'];
        $keuntunganBaris = $row['harga_jual'] - $row['nominal_harga'];
        $totalKeuntunganKeseluruhan += $keuntunganBaris * $row['jumlah'];
        $totalNominalHargaKumulatif += $row['nominal_harga'] * $row['jumlah'];
        ?>
    <?php endforeach; ?> //tag penutup dari struktur pengulangan foreach dalam PHP.
</tbody>
<tfoot>
    <tr class="total">
        <td colspan="3">Total:</td>
        <td><?= $totalJumlah; ?></td>
        <td><?= $totalNominalHargaKumulatif; ?></td>
        <td><?= $totalHargaJualKumulatif; ?></td>
        <td><?= $totalKeuntunganKeseluruhan; ?></td>
    </tr>
</tfoot>

</body>

</html>