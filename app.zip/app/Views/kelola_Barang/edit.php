<?= $this->extend('templates/main') ?>
<?= $this->section('content') ?>

<div class="content-wrapper">
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <form action="/kelola-barang/update/<?= $barang['id_barang']; ?>" method="post">
                                <?= csrf_field(); ?>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label for="id_jenis">Nama Jenis Barang</label>
                                        <select class="form-control" name="id_jenis" id="id_jenis">
                                            <option value="<?= $barang['id_jenis']; ?>">
                                                <?= $barang['jenis_barang']; ?>
                                            </option>
                                            <?php foreach ($jenis_barang as $jb) : ?>
                                                <option value="<?= $jb['id_jenis']; ?>">
                                                    <?= $jb['jenis_barang']; ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <div class="invalid-feedback">
                                            <?= $validation->getError('id_jenis'); ?>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="kode_barang">Kode Barang</label>
                                        <input type="text" class="form-control <?= ($validation->hasError('kode_barang')) ? 'is-invalid' : ''; ?>" id="kode_barang" name="kode_barang" placeholder="Masukkan Kode Barang" value="<?= old('kode_barang', $barang['kode_barang']); ?>" readonly>
                                        <div class="invalid-feedback">
                                            <?= $validation->getError('kode_barang'); ?>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="nama_barang">Nama Barang</label>
                                        <input type="text" class="form-control <?= ($validation->hasError('nama_barang')) ? 'is-invalid' : ''; ?>" id="nama_barang" name="nama_barang" placeholder="Masukkan Nama Barang" value="<?= old('nama_barang', $barang['nama_barang']); ?>">
                                        <div class="invalid-feedback">
                                            <?= $validation->getError('nama_barang'); ?>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="harga">Harga</label>
                                        <input type="text" class="form-control <?= ($validation->hasError('harga')) ? 'is-invalid' : ''; ?>" id="harga" name="harga" placeholder="Masukkan Harga" value="<?= 'Rp ' . number_format($barang['harga'], 0, ',', '.'); ?>">
                                        <div class="invalid-feedback">
                                            <?= $validation->getError('harga'); ?>
                                        </div>
                                    </div>

                                    <script>
                                        var hargaInput = document.getElementById('harga');
                                        hargaInput.addEventListener('input', function (e) {
                                            var unformatted = e.target.value.replace(/\D/g, '');
                                            e.target.value = formatRupiah(unformatted);
                                        });
                                    </script>

                                    <div class="form-group">
                                        <label for="harga_jual">Harga Jual</label>
                                        <input type="text" class="form-control <?= ($validation->hasError('harga_jual')) ? 'is-invalid' : ''; ?>" id="harga_jual" name="harga_jual" placeholder="Masukkan Harga Jual" value="<?= 'Rp ' . number_format($barang['harga_jual'], 0, ',', '.'); ?>">
                                        <div class="invalid-feedback">
                                            <?= $validation->getError('harga_jual'); ?>
                                        </div>
                                    </div>

                                    <script>
                                        var hargaJualInput = document.getElementById('harga_jual');
                                        hargaJualInput.addEventListener('input', function (e) {
                                            var unformatted = e.target.value.replace(/\D/g, '');
                                            e.target.value = formatRupiah(unformatted);
                                        });
                                    </script>

                                    <div class="form-group">
                                        <label for="stok">Stok</label>
                                        <input type="number" class="form-control <?= ($validation->hasError('stok')) ? 'is-invalid' : ''; ?>" id="stok" name="stok" placeholder="Masukkan Stok" value="<?= old('stok', $barang['stok']); ?>">
                                        <div class="invalid-feedback">
                                            <?= $validation->getError('stok'); ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="card-footer">
                                    <a class="btn btn-warning" href="/kelola-barang">Kembali</a>
                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?= $this->endSection() ?>
