<!DOCTYPE html>
<html>

<head>
    <title>Data Obat</title>
    <!-- Gaya CSS disini jika diperlukan -->
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        .header {
            text-align: center;
        }

        .alamat {
            text-align: center;
            margin-bottom: 20px;
            border-bottom: 1px solid black;
            /* Menambahkan garis bawah */
        }

        .nomor-cetak {
            text-align: right;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table,
        th,
        td {
            border: 1px solid black;
        }

        th {
            padding: 10px;
            text-align: left;
            color: #fff;
            /* Menambahkan warna teks pada th */
            background-color: #333;
            /* Menambahkan warna latar belakang pada th */
        }

        td {
            padding: 10px;
            text-align: left;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Angkringan HTS</h1>
    </div>

    <div class="alamat">
        <p>Jl. Ahmad Yani Angsau Kec. Pelaihari, Kab. Tanah Laut, Prov. Kalimantan Selatan</p>
    </div>

    <div class="nomor-cetak">
        <p>Nomor Cetak:
            <?= date('YmdHis'); ?>
        </p>
    </div>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Kode Barang</th>
                <th>Jenis Barang</th>
                <th>Nama Barang</th>
                <th>Harga</th>
                <th>Harga Jual</th>
                <th>Stok</th>
                <!-- Tambahkan kolom lainnya sesuai kebutuhan -->
            </tr>
        </thead>
        <tbody>
            <?php $totalStok = 0; ?>
            <?php $no = 1; ?>
            <?php foreach($barang as $row): ?>
                <tr>
                    <td>
                        <?= $no++; ?>
                    </td>
                    <td>
                        <?= $row['kode_barang']; ?>
                    </td>
                    <td>
                        <?= $row['jenis_barang']; ?>
                    </td>
                    <td>
                        <?= $row['nama_barang']; ?>
                    </td>
                    <td>
                        <?= 'Rp ' . number_format($row['harga'], 0, ',', '.'); ?>
                    </td>
                    <td>
                        <?= 'Rp ' . number_format($row['harga_jual'], 0, ',', '.'); ?>
                    </td>
                    <td>
                        <?= $row['stok']; ?>
                    </td>
                    <!-- Tambahkan kolom lainnya sesuai kebutuhan -->
                </tr>
                <?php $totalStok += $row['stok']; ?>
            <?php endforeach; ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="6" style="text-align: right; font-weight: bold;">Total Stok</td>
                <td style="font-weight: bold;">
                    <?= $totalStok; ?>
                </td>
            </tr>
        </tfoot>
    </table>
</body>

</html>
