<?= $this->extend('templates/main') ?>
<?= $this->section('content') ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">
                        <?= $title; ?>
                    </h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">
                            <?= $title; ?>
                        </li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                    <?php if (session('pesan')): ?>
                                <div class="alert alert-danger alert-dismissible mt-3">
                                    <button type="button" class="close" data-dismiss="alert"
                                        aria-hidden="true">&times;</button>
                                    <?= session('pesan'); ?>
                                </div>
                            <?php endif; ?>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <!-- form start -->
                            <form action="/kelola-barang/simpan" method="post">
                                <?= csrf_field(); ?>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label for="nama">Nama Jenis Barang</label>
                                        <select class="form-control" name="id_jenis" id="id_jenis">
                                            <option value="">-- Pilih Jenis Barang --</option>
                                            <?php foreach($jenis_barang as $jb): ?>
                                                <option value="<?= $jb['id_jenis']; ?>">
                                                    <?= $jb['jenis_barang']; ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <div class="invalid-feedback">
                                            <?= $validation->getError('id_jenis'); ?>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="nama">Kode Barang</label>
                                        <input type="text"
                                            class="form-control <?= ($validation->hasError('kode_barang')) ? 'is-invalid' : ''; ?>"
                                            id="kode_barang" name="kode_barang" placeholder="Masukkan Kode Barang"
                                            value="<?= old('kode_barang', 'AH-'.str_pad(rand(1, 999), 3, '0', STR_PAD_LEFT)); ?>"
                                            pattern="AH-\d{3}" >
                                        <div class="invalid-feedback">
                                            <?= $validation->getError('kode_barang'); ?>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="nama">Nama Barang</label>
                                        <input type="text"
                                            class="form-control <?= ($validation->hasError('nama_barang')) ? 'is-invalid' : ''; ?>"
                                            id="nama_barang" name="nama_barang" placeholder="Masukkan Nama Barang"
                                            value="<?= old('nama_barang'); ?>">
                                        <?php if (session('errors.nama_barang')): ?>
                                            <div class="invalid-feedback">
                                                <?= session('errors.nama_barang'); ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>

                        
                                                                    <div class="form-group">
                                    <label for="harga">Harga (SATUAN)</label>
                                    <input type="text" class="form-control <?= ($validation->hasError('harga')) ? 'is-invalid' : ''; ?>" id="harga" name="harga" placeholder="Masukkan Harga (numeric only)" value="<?= old('harga'); ?>" oninput="validateInput(this);">
                                    <?php if (session('errors.harga')): ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.harga'); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group">
                                    <label for="harga_jual">Harga Jual</label>
                                    <input type="text" class="form-control <?= ($validation->hasError('harga_jual')) ? 'is-invalid' : ''; ?>" id="harga_jual" name="harga_jual" placeholder="Masukkan Harga Jual (numeric only)" value="<?= old('harga_jual'); ?>" oninput="validateInput(this);">
                                    <?php if (session('errors.harga_jual')): ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.harga_jual'); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>


                                                                    <script>
                                    function validateInput(input) {
                                        // Remove non-numeric characters and format as Indonesian Rupiah
                                        input.value = 'Rp ' + parseFloat(input.value.replace(/[^\d.]/g, '')).toLocaleString('id-ID');
                                    }
                                </script>

                                    <div class="card-footer">
                                        <a class="btn btn-warning" href="/kelola-barang">Kembali</a>
                                        <button type="submit" id="submit-button" class="btn btn-primary">Simpan</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->

            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
</div>
<!-- /.container-fluid -->
</section>

<?= $this->EndSection() ?>