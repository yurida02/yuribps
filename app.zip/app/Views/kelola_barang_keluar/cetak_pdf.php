<!DOCTYPE html>
<html>

<head>
    <title>Laporan Barang Keluar</title>
    <!-- Gaya CSS disini jika diperlukan -->
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        .header {
            text-align: center;
        }

        .alamat {
            text-align: center;
            margin-bottom: 20px;
            border-bottom: 1px solid black;
        }

        .footer {
            margin-top: 20px;
            text-align: right;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid black;
        }

        th {
            padding: 10px;
            text-align: left;
            color: #fff;
            background-color: cornflowerblue;
        }

        td {
            padding: 10px;
            text-align: left;
        }

        .total {
            font-weight: bold;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Angkringan HTS</h1>
    </div>

    <div class="alamat">
        <p>Jl. Ahmad Yani Angsau Kec. Pelaihari, Kab. Tanah Laut, Prov. Kalimantan Selatan</p>
    </div>

    <div class="footer">
        <p>Nomor Cetak: <?= date('YmdHis'); ?></p>
    </div>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Barang</th>
                <th>Tanggal</th>
                <th>Jumlah</th>
                <th>Harga</th>
                <th>Harga Jual</th>
                <th>Keuntungan</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $no = 1;
            $totalJumlah = 0;
            $totalHargaBeliKumulatif = 0;
            $totalHargaJualKumulatif = 0;
            $totalKeuntunganKumulatif = 0;
            ?>
            <?php foreach ($barang_keluar as $row): ?>
                <?php
                $keuntungan = ($row['total_harga'] - ($row['harga'] * $row['jumlah']));
                ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= $row['nama_barang']; ?></td>
                    <td><?= date('d-m-Y H:i:s', strtotime($row['tanggal_keluar'])); ?></td>
                    <td><?= $row['jumlah']; ?></td>
                    <td><?= number_format($row['harga']); ?></td>
                    <td><?= number_format($row['total_harga']); ?></td>
                    <td><?= number_format($keuntungan); ?></td>
                </tr>
                <?php
                $totalJumlah += $row['jumlah'];
                $totalHargaBeliKumulatif += $row['harga'] * $row['jumlah'];
                $totalHargaJualKumulatif += $row['total_harga'];
                $totalKeuntunganKumulatif += $keuntungan;
                ?>
            <?php endforeach; ?>
        </tbody>
        <tfoot>
            <tr class="total">
                <td colspan="3">Total:</td>
                <td><?= $totalJumlah; ?></td>
                <td><?= number_format($totalHargaBeliKumulatif); ?></td>
                <td><?= number_format($totalHargaJualKumulatif); ?></td>
                <td><?= number_format($totalKeuntunganKumulatif); ?></td>
            </tr>
        </tfoot>
    </table>
</body>

</html>
