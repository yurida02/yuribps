<?= $this->extend('templates/main') ?>
<?= $this->section('content') ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">
                        <?= $title; ?>
                    </h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">
                            <?= $title; ?>
                        </li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <?php if (session('pesan')): ?>
                                <div class="alert alert-success alert-dismissible mt-3">
                                    <button type="button" class="close" data-dismiss="alert"
                                        aria-hidden="true">&times;</button>
                                    <?= session('pesan'); ?>
                                </div>
                            <?php endif; ?>
                            
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <button type="button" class="btn btn-primary" data-toggle="modal"
                                data-target="#staticBackdrop">
                                Tambah Data
                            </button>
                            <div class="float-right">
                                <form action="/kelola-barang-keluar/cetakpdf" method="post">
                                    <label for="tanggalawal">Tanggal Awal:</label>
                                    <input type="date" name="tanggalawal">

                                    <label for="tanggalakhir">Tanggal Akhir:</label>
                                    <input type="date" name="tanggalakhir">

                                    <button type="submit" class="btn btn-warning"><i
                                            class="fas fa-file-pdf"></i></button>
                                </form>
                            </div>
                            
                            <a class="btn btn-success mb-2" href="/kelola-barang-keluar/cetakexcel"><i
                                    class="fas fa-file-excel"></i></a>
                            <table id="example2" class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama Barang</th>
                                        <th>Jumlah</th>
                                        <th>Tanggal Keluar</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no = 1;
                                    foreach ($barang_keluar as $row): ?>
                                        <tr>
                                            <td>
                                                <?= $no++; ?>
                                            </td>
                                            <td>
                                                <?= $row['nama_barang']; ?>
                                            </td>
                                            <td>
                                                <?= $row['jumlah']; ?>
                                            </td>
                                            <td>
                                                <?= date('d-m-Y / H:i:s', strtotime($row['tanggal_keluar'])); ?>
                                            </td>
                                            <td>
                                                <a href="<?= base_url('/barang-keluar/hapus/' . $row['id_barang_keluar']); ?>"
                                                    class="btn btn-sm btn-danger"
                                                    onclick="return confirm('Apakah Anda Yakin Ingin Menghapus Data Ini?')"><i
                                                        class="fas fa-trash"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>

                                </tbody>

                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->

                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>

</div>

<!-- Modal -->
<div class="modal fade bd-example-modal-lg" id="staticBackdrop" data-backdrop="static" tabindex="-1" role="dialog"
    aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">
                    <?= $title; ?>
                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            
            <div class="modal-body">
                <!-- form group -->
                <form action="/barang-keluar/simpan" method="post" enctype="multipart/form-data">
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="">Nama Barang</label>
                            <select name="id_barang" id="id_barang" class="form-control">
                                <option value="">Pilih Barang</option>
                                <?php foreach ($barang as $row): ?>
                                    <option value="<?= $row['id_barang']; ?>" data-code="<?= $row['kode_barang']; ?>"
                                        data-harga="<?= $row['harga_jual']; ?>" data-jenis="<?= $row['id_jenis']; ?>"
                                        data-stok="<?= $row['stok']; ?>">
                                        <?= $row['nama_barang']; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group col-md-6">
                            <label for="">Jenis Barang</label>
                            <!-- Menampilkan nama jenis barang tetapi mengirimkan id_jenis_barang -->
                            <select name="id_jenis" id="jenis_barang" class="form-control" readonly>
                                <?php foreach ($jenis_barang as $jenis): ?>
                                    <option value="<?= $jenis['id_jenis']; ?>">
                                        <?= $jenis['jenis_barang']; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group col-md-6">
                            <label for="">Kode Barang</label>
                            <input type="text" class="form-control" id="kode_barang" name="kode_barang" readonly>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="">Jumlah</label>
                            <p id="stok_tersedia">Stok Tersedia:</p>
                            <input type="number" class="form-control" id="jumlah" name="jumlah">
                        </div>
                        <script>
                            document.addEventListener('DOMContentLoaded', function () {
                                var inputJumlah = document.getElementById('jumlah');

                                inputJumlah.addEventListener('input', function () {
                                    // Hapus karakter selain angka
                                    inputJumlah.value = inputJumlah.value.replace(/\D/g, '');
                                });
                            });
                        </script>

                        <div class="form-group col-md-6">
                            <label for="">Harga Jual</label>
                            <input type="text" class="form-control" id="harga_jual" readonly>
                        </div>
                    </div>

                    <div class="form-group col-md-12">
                        <label for="">Total Harga</label>
                        <input type="type" class="form-control" id="total_harga" name="total_harga" readonly>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Keluar</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>

                    <!-- cdn jquery -->
                    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
                    <script>
                        document.addEventListener('DOMContentLoaded', function () {
                            var selectBarang = document.getElementById('id_barang');
                            var inputKodeBarang = document.getElementById('kode_barang');
                            var inputJumlah = document.getElementById('jumlah');
                            var inputHargaJual = document.getElementById('harga_jual');
                            var inputTotalHarga = document.getElementById('total_harga');
                            var inputJenis = document.getElementById('jenis_barang');
                            var inputStokTersedia = document.getElementById('stok_tersedia');
                            var submitButton = document.getElementById('submit_button');

                            selectBarang.addEventListener('change', function () {
                                var selectedOption = selectBarang.options[selectBarang.selectedIndex];
                                var kodeBarang = selectedOption.getAttribute('data-code');
                                var hargaJual = selectedOption.getAttribute('data-harga');
                                var jenisBarang = selectedOption.getAttribute('data-jenis');
                                var stokTersedia = parseFloat(selectedOption.getAttribute('data-stok'));

                                // Update input values
                                inputKodeBarang.value = kodeBarang;
                                inputHargaJual.value = hargaJual;
                                inputJenis.value = jenisBarang;

                                // Jika stok kosong, tampilkan pesan, nonaktifkan input jumlah, dan set nilai input jumlah menjadi 0
                                if (stokTersedia <= 0) {
                                    inputStokTersedia.innerText = 'Stok Tersedia: 0';
                                    inputJumlah.value = 0;
                                    showErrorAlert('Stok barang kosong. Tidak dapat menambahkan jumlah.');
                                } else {
                                    inputStokTersedia.innerText = 'Stok Tersedia: ' + stokTersedia;
                                }

                                // Jika jumlah barang keluar melebihi stok, set nilai input jumlah menjadi 0
                                if (parseFloat(inputJumlah.value) > stokTersedia) {
                                    inputJumlah.value = 0;
                                }

                                // Update tombol submit berdasarkan stok dan jumlah
                                updateSubmitButton();
                            });

                            // Contoh perhitungan total harga (gantilah dengan logika perhitungan yang sesuai)
                            inputJumlah.addEventListener('input', hitungTotalHarga);
                            inputHargaJual.addEventListener('input', hitungTotalHarga);

                            function hitungTotalHarga() {
                                var jumlah = parseFloat(inputJumlah.value) || 0;
                                var hargaJual = parseFloat(inputHargaJual.value) || 0;
                                var stokTersedia = parseFloat(inputStokTersedia.innerText.split(' ')[2]) || 0;

                                // Jika jumlah melebihi stok yang tersedia, set nilai input jumlah menjadi 0
                                if (jumlah > stokTersedia) {
                                    showErrorAlert('Jumlah melebihi stok yang tersedia.');
                                    inputJumlah.value = 0;
                                }

                                var totalHarga = jumlah * hargaJual;
                                inputTotalHarga.value = totalHarga;

                                // Update tombol submit berdasarkan stok dan jumlah
                                updateSubmitButton();
                            }

                            function updateSubmitButton() {
                                var jumlah = parseFloat(inputJumlah.value) || 0;
                                var stokTersedia = parseFloat(inputStokTersedia.innerText.split(' ')[2]) || 0;

                                // Jika jumlah barang keluar melebihi stok, tampilkan pesan
                                if (jumlah > stokTersedia) {
                                    showErrorAlert('Jumlah barang keluar melebihi stok yang tersedia.');
                                }
                            }

                            function showErrorAlert(message) {
                                alert('Error: ' + message);
                            }
                        });
                    </script>

                </form>
            </div>
        </div>
    </div>
</div>
<?= $this->EndSection()?>
