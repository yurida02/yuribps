<footer class="main-footer">
    <strong>Badan Pusat Statistik<a href="https://adminlte.io"></a></strong>
    <div class="float-right d-none d-sm-inline-block">
        <b>Tanah Laut</b> 
    </div>
</footer>